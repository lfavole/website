"""
L'application de base.
En effet, dans tous les projets Django, il faut une application de base avec les paramètres (settings.py).
Normalement elle a le nom du dossier parent mais ici ce n'est pas le cas.
"""
