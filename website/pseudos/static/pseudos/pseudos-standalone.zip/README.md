# Générateur de pseudos

Voici le code du générateur de pseudos.

Regardez les commentaires que j'ai laissés dans les différents fichiers, ils vont vous aider à comprendre le code.

## Utilisation

Avant le premier lancement, il faut effectuer les migrations (créer les tables dans la base de données) : `python manage.py migrate`, sinon les sessions (données rattachées à un visiteur du site) ne pourront pas être créées.
Cela créera 3 tables (`django_content_types`, `django_migrations` et `django_session`).
Pour les sessions, voir <https://docs.djangoproject.com/fr/4.1/topics/http/sessions>.

Pour lancer le générateur de pseudos :

* `python __init__.py` : lance le programme sur un serveur Waitress
* `python manage.py runserver` : lance le serveur de développement qui se recharge quand on modifie un fichier et affiche les erreurs habituelles.

Les programmes lanceront les commandes `pip` automatiquement si nécessaire pour télécharger les programmes manquants.

## Compilation du programme

J'ai essayé de compiler le programme (créer un fichier .exe) avec PyInstaller, c'est très compliqué voire impossible.
