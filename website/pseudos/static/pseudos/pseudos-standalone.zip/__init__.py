"""
Lance le générateur de pseudos sur un serveur Waitress.
C'est ce programme que j'ai essayé de compiler en .exe.
"""
import os

try:
    import django
except ImportError:
    print("Django n'est pas installé, installation...")
    os.system("pip install django") # installer Django
    print("Installation terminée")
    import django

try:
    from waitress import serve
except ImportError:
    print("Waitress n'est pas installé, installation...")
    os.system("pip install waitress") # installer Waitress
    print("Installation terminée")
    from waitress import serve

SETTINGS_MODULE = "pseudos_base.settings"

def main(host = "0.0.0.0", port = 8000):
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", SETTINGS_MODULE)

    from pseudos_base.wsgi import application
    url = f"http://{'127.0.0.1' if host == '0.0.0.0' else host}:{port}"
    print(f"Le générateur de pseudos est disponible à l'URL {url}.")
    try:
        os.startfile(url)
    except:
        print("Impossible de démarrer le navigateur !")
    serve(application, host = host, port = port)

if __name__ == "__main__":
	main()
