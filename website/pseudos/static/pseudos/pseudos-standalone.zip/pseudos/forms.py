from django import forms
from django.core.validators import MinValueValidator


class PseudosForm(forms.Form):
    """
    Formulaire pour créer les pseudos.
    """
    mots = forms.CharField(
        label = "Mots",
        widget = forms.Textarea(attrs = {"rows": "10", "placeholder": "1 mot par ligne\nÉcrivez votre nom par exemple"}),
        help_text = "Les synonymes de ces mots seront inclus",
    )
    nb_syllabes = forms.IntegerField(
        label = "Nombre de syllabes",
        initial = 4,
        validators = [MinValueValidator(1)],
    )
    nb_mots = forms.IntegerField(
        label = "Nombre de noms",
        initial = 10,
        validators = [MinValueValidator(0)],
        help_text = "0 pour lister toutes les possibilités",
    )
