"""
Les vues sont des programmes qui s'occupent de gérer les requêtes.
Elles vont chercher et enregister les données,
qui sont passés aux gabarits pour être affichées.
"""
from django.http import HttpRequest
from django.shortcuts import redirect, render

from .forms import PseudosForm
from .gen_pseudos import pseudos_complet


def _normaliser(liste: list[str]):
    """
    Normaliser une liste de mots (enlever les mots en double).
    """
    liste = [e.strip() for e in liste]
    # c'est la seule solution (set() ne garde pas l'ordre)
    nv_liste = []
    nv_liste_lower = []
    for e in liste:
        if e.lower() not in nv_liste_lower:
            nv_liste.append(e)
            nv_liste_lower.append(e.lower())
    liste = [e for e in nv_liste if e]
    return liste

def _liste_str(liste: str):
    """
    Normalise des mots séparés par une nouvelle ligne.
    """
    return _normaliser(liste.split("\n"))

def _join(liste: list[str]):
    """
    Ajoute une nouvelle ligne entre chaque mot.
    """
    return "\n".join(liste)

def ajouter(request: HttpRequest, nom: str):
    """
    Page qui permet d'ajouter un pseudo
    (accessible en cliquant sur les résultats).
    Le paramètre (nom) est passé à la fonction.
    """
    s_mots = _liste_str(request.session.get("pseudos_mots", ""))
    s_derniers_mots = _liste_str(request.session.get("pseudos_derniers_mots", ""))
    if nom:
        # ajoute le nom dans la liste
        s_mots.append(nom)
        s_derniers_mots.append(nom)
        request.session["pseudos_mots"] = _join(s_mots)
        request.session["pseudos_derniers_mots"] = _join(s_derniers_mots[0:10])
    # rediriger vers la page d'accueil
    return redirect("pseudos:home")

def home(request: HttpRequest):
    """
    Page d'accueil / liste des pseudos demandés.
    Ce doit être sur la même page à cause du formulaire.
    """
    # s = session
    # dernière requête (dernière valeur du champ "mots")
    s_mots = _liste_str(request.session.get("pseudos_mots", ""))
    # derniers mots utilisés
    s_derniers_mots = _liste_str(request.session.get("pseudos_derniers_mots", ""))

    # requête POST = valider le formulaire ?
    if request.method == "POST":
        form = PseudosForm(request.POST)
        if form.is_valid():
            # données
            data = form.cleaned_data
            # liste des mots
            mots = _liste_str(data["mots"])
            # enregistrement dans la session des mots (derniers mots)
            request.session["pseudos_derniers_mots"] = _join(mots)
            # enregistrement dans la session de l'historique des mots (seulement 10 mots)
            s_mots = mots + s_mots
            s_mots = _normaliser(s_mots)[0:10]
            request.session["pseudos_mots"] = _join(s_mots)
            try:
                # création du pseudo
                resultat = pseudos_complet(*mots, nb_syllabes = data["nb_syllabes"], nb_mots = data["nb_mots"])
                return render(request, "pseudos/resultat.html", {
                    "mots": mots,
                    "synonymes": resultat["synonymes"],
                    "pseudos": resultat["pseudos"],
                })
            except ValueError as err:
                # erreur = l'afficher sur le formulaire
                form.add_error("mots", str(err))
    else:
        # créer le formulaire avec les données de la session
        initial = {"mots": _join(s_derniers_mots)} if s_derniers_mots else {}
        form = PseudosForm(initial = initial)

    # afficher la page
    return render(request, "pseudos/home.html", {
        "form": form,
        "mots": s_mots,
    })
