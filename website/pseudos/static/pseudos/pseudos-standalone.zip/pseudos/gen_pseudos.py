r"""
Fichier qui s'occupe de générer les pseudos.
On peut l'exécuter directement (python pseudos\gen_pseudos.py).
"""
import itertools
import os
import random
import re

try:
    import requests
except ImportError:
    print("Requests n'est pas installé, installation...")
    os.system("pip install requests") # installer Requests
    print("Installation terminée")
    import requests

try:
    import pyphen
except ImportError:
    print("Pyphen n'est pas installé, installation...")
    os.system("pip install pyphen") # installer Pyphen
    print("Installation terminée")
    import pyphen


def synonymes(mot):
    """
    Renvoie tous les synonymes d'un mot.
    """
    # on va chercher les synonymes sur le site
    try:
        req = requests.get(f"https://crisco4.unicaen.fr/des/synonymes/{mot}")
    except IOError:
        return []

    if req.status_code >= 400:
        return []

    data = req.text

    table = re.search(r'(?s)<table[^>]*>(.*?)</table>', data)

    if not table:
        return []

    syn = re.findall('<a[^>]+>(?:&nbsp;)*([\w \'-]+)(?:&nbsp;)*</a>', table.group(1))
    return syn

def factorielle(nombre):
    ret = 1
    for i in range(1, nombre + 1):
        ret *= i
    return ret

def pseudos_complet(*mots, nb_syllabes = 3, nb_mots = 1, verbose = False):
    """
    Créer un pseudo en fonction de différents noms.
    Renvoie les synonymes et les pseudos.
    """
    parties = [] # syllabes de tous les prénoms

    # découpage des noms avec Pyphen
    # mais problème avec les noms de plus de 2 syllabes
    dic = pyphen.Pyphen(lang = "fr_FR") # instance Pyphen
    mots = list(set(mot.lower() for mot in mots)) # enlever les noms en double, mettre en minuscules

    # ajout des synonymes
    syn_ret = {}
    # on copie la liste car des éléments sont ajoutés dans la boucle
    for mot in mots.copy():
        syn = synonymes(mot)
        if not syn:
            continue
        syn_ret[mot] = syn
        if verbose:
            print(f"Synonymes de {mot} : " + ", ".join(syn))
        mots.extend(syn)
    mots = list(set(mot.lower() for mot in mots))

    if verbose:
        print()

    for mot in mots:
        syllabes = dic.inserted(mot).split("-")
        parties.extend(syllabes) # ajout des syllabes

    if nb_syllabes > len(parties):
        raise ValueError(f"Pas assez de syllabes (seulement {len(parties)}) !")

    ret = [] # liste de tous les noms demandés

    # génération de tous les noms demandés
    total_max = factorielle(len(parties)) // factorielle(len(parties) - nb_syllabes) # nombre d'arrangements
    if nb_mots > total_max:
        raise ValueError(f"Pas assez de combinaisons (maximum = {total_max}) !")
    total = total_max if nb_mots == 0 else nb_mots # 0 = tous les arrangements possibles

    if total >= total_max * 0.2:
        # utiliser les arrangements si on demande plus de 20% de la liste (plus rapide)
        arrs = itertools.permutations(parties, nb_syllabes)
        def obtenir_nom():
            return "".join(next(arrs))
    else:
        # sinon, utiliser random
        def obtenir_nom():
            parties_copie = parties.copy() # copie de la liste (pour pouvoir générer plusieurs noms)
            nom_final = "" # nom final
            for _ in range(nb_syllabes):
                i = random.randint(0, len(parties_copie) - 1) # index de la partie choisie
                nom_final += parties_copie.pop(i) # ajoute la partie au nom final et l'enlève de la liste
            return nom_final

    while total > 0:
        try:
            nom_final = obtenir_nom()
        except StopIteration:
            raise ValueError(f"Pas assez de combinaisons sans mot entier dedans (maximum = {total_max - total}) !")
        stop = False
        for mot in mots:
            if mot in nom_final: # ne pas garder le nom s'il y a un mot entier dedans
                stop = True
                break
        if stop:
            continue
        nom_final = nom_final.title().strip() # ajout des majuscules aux mots, suppression des espaces en trop
        if nom_final in ret: # ajouter le nom s'il n'y est pas déjà
            continue
        ret.append(nom_final)
        total -= 1

    return {"synonymes": syn_ret, "pseudos": ret}

def pseudo(*args, **kwargs):
    """
    Créer un pseudo en fonction de différents noms.
    """
    return pseudos_complet(*args, **kwargs)["pseudos"]

# si on lance directement le fichier (≠ interface web)
if __name__ == "__main__":
    mots = [] # liste des mots
    while True:
        mot = input("Mot : ").strip() # demande un nom
        if mot == "stop":
            break # arrêter de demander des noms quand on écrit "stop"
        mots.append(mot)

    nb_syllabes = int(input("Nombre de syllabes : "))

    nb_mots = int(input("Nombre de pseudos à générer : "))

    print()

    pseudos = pseudo(*mots, nb_syllabes = nb_syllabes, nb_mots = nb_mots, verbose = True)
    # affiche tous les noms demandés
    for pseudo in pseudos:
        print(pseudo)
