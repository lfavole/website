// Programme qui s'occupe des clics sur les derniers mots / photos.

document.addEventListener("DOMContentLoaded", function() {
	var mots = document.querySelector("textarea[name=mots]");
	// dans le cas où on n'est pas sur la page des mots
	if(!mots)
		return;

	// fonction pour ajouter un mot à la liste des mots
	function ajouterMot(mot) {
		mots.value += "\n" + mot;
	}
	// derniers mots
	var elements1 = document.querySelectorAll(".derniers-mots li");
	for(var index1 = 0, length1 = elements1.length; index1 < length1; index1++) {
		elements1[index1].addEventListener("click", function() {
			ajouterMot(this.textContent);
		});
	}
	// photos
	var elements2 = document.querySelectorAll("aside img");
	for(var index2 = 0, length2 = elements2.length; index2 < length2; index2++) {
		elements2[index2].addEventListener("click", function() {
			ajouterMot(this.getAttribute("alt"));
		});
	}
});
